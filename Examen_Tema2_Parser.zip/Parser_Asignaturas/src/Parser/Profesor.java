package Parser;

public class Profesor {
	private String nombreDelProfesor;
	private String despacho;
	
	public Profesor ()
	{
		
	}
	
	public Profesor (String nombreDelProfesor, String despacho)
	{
		this.nombreDelProfesor = nombreDelProfesor;
		this.despacho = despacho;
	}

}
