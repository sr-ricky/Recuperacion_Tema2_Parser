package Parser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class Parsear_Asignatura {
	private Document dom = null;
	ArrayList<Asignatura> asignaturas = null;
	
	
	public Parsear_Asignatura()
	{
		asignaturas = new ArrayList<Asignatura>();
	}
	
	public void ParsearFicheroXML(String nombre)
	{
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder db = dbf.newDocumentBuilder();
			dom = db.parse(nombre);
		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (SAXException se) {
			se.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void ParseDocument()
	{
		Element docElement = dom.getDocumentElement();
		NodeList nl = docElement.getElementsByTagName("asignatura");
		if (nl != null && nl.getLength() > 0) {
			for (int i = 0; i < nl.getLength(); i++) {
				
				Element el = (Element) nl.item(i);
				Asignatura asignatura = getAsignatura(el);
				asignaturas.add(asignatura);
			}
		}
	}

	private Asignatura getAsignatura(Element el) {
		ArrayList<String> profesor = new ArrayList<String>();
		int anyo = 0;
		String nombre = getTextValue(el, "nombre");
		int horas = getIntValue(el, "horas");
		
		
		NodeList nl1 = el.getElementsByTagName("profesor");
		if (nl1 != null && nl1.getLength()>0)
		{
			Element element = (Element) nl1.item(0);
			NodeList nl2 = el.getElementsByTagName("nombre");
			NodeList nl3 = el.getElementsByTagName("despacho");
			if (nl2 != null && nl2.getLength()>0 || nl3 != null && nl3.getLength()>0)
			{
				for (int x = 0; x<nl2.getLength(); x++)
				{
					Element elementNombre = (Element) nl2.item(x);
					String nombreProfesor = elementNombre.getFirstChild().getNodeValue();
					profesor.add(nombreProfesor);
				}
				for (int j = 0 ; j<nl3.getLength(); j++)
				{
					Element elementDespacho = (Element) nl3.item(j);
					String despacho = elementDespacho.getFirstChild().getNodeName();
					profesor.add(despacho);
				}
			}
			
		}
		Asignatura a = new Asignatura (nombre, horas, profesor);
		return a;
	}
	
	public void Print()
	{
		Iterator it = asignaturas.iterator();
		while (it.hasNext())
		{
			Asignatura a = (Asignatura) it.next();
			a.Print();
		}
		
	}

	private int getIntValue(Element el, String tagName) {
		return Integer.parseInt(getTextValue(el, tagName));
	}

	private String getTextValue(Element el, String tagName) {
		String textVal = null;
		NodeList nl = el.getElementsByTagName(tagName);
		if (nl != null && nl.getLength() > 0)
		{
			Element ele = (Element)nl.item(0);
			textVal = ele.getFirstChild().getNodeValue();
		}
		return textVal;
	}
	
	

}
