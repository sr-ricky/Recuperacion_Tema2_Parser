package Parser;

import java.util.ArrayList;
import java.util.Iterator;

public class Asignatura {
	private String nombre;
	private int horas;
	private ArrayList<String> profesor;
	
	
	public Asignatura(String nombre, int horas, ArrayList<String> profesor)
	{
		this.nombre = nombre;
		this.horas = horas;
		this.profesor = profesor;
	}
	
	
	
	public String getDatosProfesor()
	{
		Iterator it = profesor.iterator(); 
		String resultado = "";
		while (it.hasNext())
		{
			String nombreProfesor = (String) it.next();
			resultado=resultado+","+nombreProfesor;
			
		}
		return resultado;
	}
	
	public void Print ()
	{
		System.out.println("Nombre: "+nombre+", Horas: "+horas+", "+getDatosProfesor());
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getHoras() {
		return horas;
	}

	public void setHoras(int horas) {
		this.horas = horas;
	}

	public ArrayList<String> getProfesor() {
		return profesor;
	}

	public void setProfesor(ArrayList<String> profesor) {
		this.profesor = profesor;
	}
	
	

}
