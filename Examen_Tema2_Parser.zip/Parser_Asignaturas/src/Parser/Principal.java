package Parser;

public class Principal {

	public static void main(String[] args) {
		Parsear_Asignatura pa = new Parsear_Asignatura();
		pa.ParsearFicheroXML("asignaturas.xml");
		pa.ParseDocument();
		pa.Print();

	}

}
